import express from 'express';
import { validateEnv } from './utils/env';
import { logger } from './utils/logger';
import { setupSecurityMiddleware } from './middlewares/security';
import { sessionStore } from './utils/redis';

const startTime = Date.now();

validateEnv();

const app = express();
const PORT = process.env.PORT || 5000;

setupSecurityMiddleware(app);

app.get('/api/health', (req, res) => {
  const uptime = Math.floor((Date.now() - startTime) / 1000);
  res.json({
    status: 'ok',
    uptime,
    timestamp: new Date().toISOString(),
  });
});

app.listen(PORT, () => {
  logger.info(`🚀 Backend server running on port ${PORT}`);
  logger.info(`📊 Health check: http://localhost:${PORT}/api/health`);
  logger.info(`🌍 Environment: ${process.env.NODE_ENV || 'development'}`);
});
