import helmet from 'helmet';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import cookieParser from 'cookie-parser';
import express from 'express';
import { logger } from '../utils/logger';

export function setupSecurityMiddleware(app: express.Express) {
  app.use(helmet());
  logger.info('✓ Helmet security headers enabled');

  app.use(cors({
    origin: true,
    credentials: true,
  }));
  logger.info('✓ CORS enabled with credentials support');

  app.use(express.json({ limit: '10mb' }));
  app.use(cookieParser());
  logger.info('✓ JSON and cookie parsing enabled');

  const limiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 100,
    message: 'Too many requests from this IP, please try again later.',
    standardHeaders: true,
    legacyHeaders: false,
  });

  app.use(limiter);
  logger.info('✓ Rate limiting enabled (100 req/15min)');
}
