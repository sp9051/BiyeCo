export function validateEnv() {
  const required = [
    'DATABASE_URL',
    'PORT',
    'NODE_ENV',
    'JWT_SECRET',
  ];

  const missing = required.filter(key => !process.env[key]);

  if (missing.length > 0) {
    throw new Error(`Missing required environment variables: ${missing.join(', ')}`);
  }

  console.log('✓ All required environment variables validated');
}
