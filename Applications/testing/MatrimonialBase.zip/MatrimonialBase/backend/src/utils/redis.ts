class InMemoryStore {
  private store: Map<string, any>;

  constructor() {
    this.store = new Map();
    console.log('✓ In-memory session store initialized');
  }

  async get(key: string): Promise<any | null> {
    try {
      return this.store.get(key) || null;
    } catch (error) {
      console.error('Error getting from store:', error);
      throw error;
    }
  }

  async set(key: string, value: any, ttl?: number): Promise<void> {
    try {
      this.store.set(key, value);
      if (ttl) {
        setTimeout(() => {
          this.store.delete(key);
        }, ttl * 1000);
      }
    } catch (error) {
      console.error('Error setting to store:', error);
      throw error;
    }
  }

  async delete(key: string): Promise<void> {
    try {
      this.store.delete(key);
    } catch (error) {
      console.error('Error deleting from store:', error);
      throw error;
    }
  }

  async clear(): Promise<void> {
    try {
      this.store.clear();
    } catch (error) {
      console.error('Error clearing store:', error);
      throw error;
    }
  }
}

export const sessionStore = new InMemoryStore();
