import request from 'supertest';
import express from 'express';
import { setupSecurityMiddleware } from '../middlewares/security';

const app = express();
setupSecurityMiddleware(app);

const startTime = Date.now();

app.get('/api/health', (req, res) => {
  const uptime = Math.floor((Date.now() - startTime) / 1000);
  res.json({
    status: 'ok',
    uptime,
    timestamp: new Date().toISOString(),
  });
});

describe('GET /api/health', () => {
  it('should return health status', async () => {
    const response = await request(app).get('/api/health');
    
    expect(response.status).toBe(200);
    expect(response.body).toHaveProperty('status', 'ok');
    expect(response.body).toHaveProperty('uptime');
    expect(response.body).toHaveProperty('timestamp');
    expect(typeof response.body.uptime).toBe('number');
  });
});
