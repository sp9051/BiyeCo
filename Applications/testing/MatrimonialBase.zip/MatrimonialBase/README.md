# Biye Matrimonial Platform - Module 0

## 🎯 Project Overview

This is the secure foundation (Module 0) for the Biye matrimonial platform. It provides a production-ready full-stack application with backend (Express + TypeScript) and frontend (React + Vite), complete with security middleware, database integration, and in-memory session storage.

## 📁 Project Structure

```
/biye-matrimonial
├── server/                    # Backend (Express + TypeScript)
│   ├── modules/              # Placeholder for future modules (auth, chat, etc.)
│   ├── middlewares/          # Custom middleware
│   ├── utils/                # Utilities (logger, env validation, session store)
│   ├── index.ts              # Main server entry with security middleware
│   ├── routes.ts             # API routes (includes health check)
│   └── storage.ts            # In-memory storage interface
│
├── client/                   # Frontend (React + Vite)
│   ├── src/
│   │   ├── components/       # React components
│   │   ├── pages/            # Page components
│   │   ├── lib/              # Frontend utilities
│   │   ├── App.tsx           # Main app component
│   │   └── index.css         # Global styles
│   └── index.html
│
├── shared/                   # Shared types and schemas
│   └── schema.ts             # Drizzle ORM schema (baseline User model)
│
├── backend/                  # Module 0 documentation structure
│   ├── src/
│   │   ├── prisma/           # Prisma schema reference (using Drizzle instead)
│   │   └── __tests__/        # Jest tests
│   └── package.json          # Backend npm scripts reference
│
├── .env.example              # Sample environment variables
├── .gitignore
└── README.md
```

## 🔧 Tech Stack

### Backend
- **Node.js** + **Express** + **TypeScript**
- **Drizzle ORM** (PostgreSQL)
- **Security**: Helmet, CORS, Express Rate Limit, Cookie Parser
- **In-memory session store** (Redis alternative for MVP)
- **Testing**: Jest + Supertest

### Frontend
- **React 18** + **Vite**
- **Wouter** (routing)
- **Tailwind CSS**
- **TypeScript**
- **TanStack Query** (data fetching)

## 🚀 Getting Started

### Prerequisites
- Node.js 18+ installed
- PostgreSQL database available
- Environment variables configured

### 1. Setup Environment Variables

The project uses Replit's environment management. Required variables:
- `DATABASE_URL`: PostgreSQL connection string (automatically provisioned)
- `PORT`: Server port (default: 5000)

### 2. Install Dependencies

Dependencies are automatically installed via Replit's packager. All required packages are already configured.

### 3. Database Setup

Push schema to database:

```bash
npm run db:push
```

### 4. Run Development Server

Start the full-stack application:

```bash
npm run dev
```

Server runs on http://localhost:5000 (serves both frontend and API)

## ✅ Verification Checklist

Before proceeding to next module, verify:

- [ ] Backend health check responds: `GET http://localhost:5000/api/health`
  - Returns: `{ "status": "ok", "uptime": <seconds>, "timestamp": "<ISO string>" }`
- [ ] Frontend homepage renders at http://localhost:5000
- [ ] Database schema pushed successfully
- [ ] All environment variables validated at server startup
- [ ] Security middleware active: Helmet, CORS, Rate Limiting (100 req/15min)
- [ ] In-memory session store initialized
- [ ] Storage interface works for baseline User model

## 📊 API Endpoints

### Health Check
```
GET /api/health
```
**Response:**
```json
{
  "status": "ok",
  "uptime": 123,
  "timestamp": "2024-01-01T00:00:00.000Z"
}
```

## 🔒 Security Features

- ✅ **Helmet**: HTTP security headers
- ✅ **CORS**: Cross-origin resource sharing with credentials support
- ✅ **Rate Limiting**: 100 requests per 15 minutes per IP
- ✅ **Cookie Parser**: Secure cookie handling
- ✅ **Environment Validation**: Startup fails if required variables missing
- ✅ **JSON Body Parsing**: 10MB limit to prevent DoS

## 🧪 Testing

The project includes a Jest test for the health check endpoint in `backend/src/__tests__/health.test.ts` as a reference for Module 0 requirements. Additional tests will be added in future modules.

## 📝 Development Scripts

### Main Application
- `npm run dev` - Start full-stack development server
- `npm run build` - Build for production
- `npm run db:push` - Push database schema changes

### Backend Reference (Module 0 documentation)
- Backend scripts are documented in `backend/package.json` for reference
- Actual development uses the main `npm run dev` command

## 📦 Next Steps

This is Module 0 - the secure foundation. Future modules will add:

1. **Authentication Module** (`/backend/src/modules/auth`)
2. **Profile Management** (`/backend/src/modules/profile`)
3. **Chat System** (`/backend/src/modules/chat`)
4. **Matching Algorithm** (`/backend/src/modules/matching`)

The frontend is currently unstyled and ready for Figma design integration.

## 🛠️ Architecture Notes

- **Monorepo structure**: Backend and frontend are independent but share configuration
- **Modular backend**: Future features go in `/backend/src/modules/`
- **Security-first**: All middleware configured for production use
- **TypeScript throughout**: Type safety on both backend and frontend
- **Database-ready**: Prisma configured with baseline User schema
- **Logging**: Structured JSON logs for production monitoring
- **Testing ready**: Jest configured with sample health check test

## 📄 License

MIT
