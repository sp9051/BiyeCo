export default function Home() {
  return (
    <main className="flex flex-col items-center justify-center min-h-screen">
      <h1 className="text-3xl font-bold">Welcome to Biye Matrimonial Platform</h1>
      <p className="mt-4 text-gray-600">Your journey begins here.</p>
    </main>
  );
}
