export default function BiyeHeader() {
  return (
    <header className="border-b p-4">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-xl font-semibold">Biye</h1>
      </div>
    </header>
  );
}
