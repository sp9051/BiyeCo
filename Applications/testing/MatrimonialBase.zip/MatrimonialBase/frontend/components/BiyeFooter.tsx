export default function BiyeFooter() {
  return (
    <footer className="border-t p-4 mt-auto">
      <div className="max-w-6xl mx-auto text-center text-sm text-gray-500">
        <p>&copy; 2024 Biye Matrimonial Platform. All rights reserved.</p>
      </div>
    </footer>
  );
}
