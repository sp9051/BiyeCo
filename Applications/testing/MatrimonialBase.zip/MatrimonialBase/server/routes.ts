import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

const startTime = Date.now();

export async function registerRoutes(app: Express): Promise<Server> {
  // Health check endpoint for Module 0
  app.get('/api/health', (req, res) => {
    const uptime = Math.floor((Date.now() - startTime) / 1000);
    res.json({
      status: 'ok',
      uptime,
      timestamp: new Date().toISOString(),
    });
  });

  // Future routes will be added here
  // prefix all routes with /api

  const httpServer = createServer(app);

  return httpServer;
}
