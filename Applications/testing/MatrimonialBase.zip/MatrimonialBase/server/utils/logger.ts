import winston from 'winston';

// Module 0: Winston logger with JSON formatting and timestamps
export const logger = winston.createLogger({
  level: process.env.NODE_ENV === 'production' ? 'info' : 'debug',
  format: winston.format.combine(
    winston.format.timestamp({
      format: 'YYYY-MM-DD HH:mm:ss',
    }),
    winston.format.errors({ stack: true }),
    winston.format.json()
  ),
  transports: [
    new winston.transports.Console({
      format: winston.format.combine(
        winston.format.colorize(),
        winston.format.printf(({ timestamp, level, message, ...meta }) => {
          return `${timestamp} [${level}]: ${message} ${Object.keys(meta).length ? JSON.stringify(meta, null, 2) : ''}`;
        })
      ),
    }),
  ],
});

export function logInfo(message: string, meta?: any) {
  logger.info(message, meta);
}

export function logError(message: string, error?: any) {
  logger.error(message, { error: error?.message || error });
}

export function logDebug(message: string, meta?: any) {
  logger.debug(message, meta);
}
